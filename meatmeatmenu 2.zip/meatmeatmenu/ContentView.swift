//
//  ContentView.swift
//  meatmeatmenu
//
//  Created by User03 on 2020/10/18.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        //TabView {
            NavigationView{
                List{
                    ScrollView( .horizontal, showsIndicators:false){
                        HStack(spacing : 20){
                            ForEach(0..<6){(item)in
                                Image("family\(item)").resizable()
                                    .scaledToFill()
                                    .frame(width: 200)
                                    .clipped()
                                    .border(Color.black, width: 2)
                            }
                        }
                        .frame(height: 200)
                    }
                    ForEach(1..<4){(item)in
                        HStack{
                            Image("fat\(item)")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 190)
                                .clipped()
                            Image("meat\(item)")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 190)
                                .clipped()
                        }
                        .frame(height:170)
                    }
                }
                .navigationBarTitle("肉肉家族").padding().background(Color(red: 1, green: 0.6, blue: 0.6)).cornerRadius(20)
            }
            
            
            
           // Color.blue
                
        //}
        //.tabViewStyle(PageTabViewStyle())
    }
}/*
struct Rightfat1View: View{
    var body: some View{
        
    }
}

*/
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

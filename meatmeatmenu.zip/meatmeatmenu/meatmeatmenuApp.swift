//
//  meatmeatmenuApp.swift
//  meatmeatmenu
//
//  Created by User03 on 2020/10/18.
//

import SwiftUI

@main
struct meatmeatmenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
